#ifndef MAP_H
#define MAP_H

#include <iostream>
#include <utility>
#include "RBTree.h"
using namespace std;

// map class declaration
template<class T, class V>
class map : public RBTree<T, V>{
private:
    void copy(RBTreeNode<T, V>*, RBTreeNode<T, V>*&, RBTreeNode<T, V>*, RBTreeNode<T, V> *NilPtr);
    ostream& InOrderDisplay(RBTreeNode<T, V> *, ostream&);
    void InOrderVector(RBTreeNode<T, V>*, vector<pair<T, V>>&);
    void InOrderArray(RBTreeNode<T, V>*, T [], int &n, const int);

    bool InOrderSubset(RBTreeNode<T, V>*, map<T, V>&);
    bool InOrderSubset(RBTreeNode<T, V>*, RBTreeNode<T, V>*);
public:
    map();
    map(const map<T, V>&);
    ~map();
    
    // insert a value into the map
    void insert(T, V);
    // find a value 
    bool find(T);
    //erase a value from the map
    void erase(T);
    // empty function to check if empty
    bool empty();
    
    int size();
    
    void clear();

    V get(T key);

    void set(T key, V value);

    // convert the multiset to a vector
    void toVector(vector<pair<T, V>>&);

    // overloaded assignment operator
    map<T, V> operator=(const map<T, V>& right);

    bool operator==(map<T, V>& right);

    bool operator!=(map<T, V>& right);

    template<class c, class z>
    friend ostream& operator<<(ostream& os, map<c, z>& obj);
};
    
template<class T, class V>
map<T, V>::map()
{
}

/*
 * copy each node recursively in a sub tree pointed to by nodePtr
 */
template<class T, class V>
void map<T, V>::copy(RBTreeNode<T, V> *nodePtr, RBTreeNode<T, V> *&next, RBTreeNode<T, V> *parent, RBTreeNode<T, V> *NilPtr)
{
    if(nodePtr != NilPtr){
        next = new RBTreeNode<T, V>(nodePtr->key, nodePtr->value, nodePtr->color, RBTree<T, V>::NIL, RBTree<T, V>::NIL, parent);
        copy(nodePtr->left, next->left, next, NilPtr);
        copy(nodePtr->right, next->right, next, NilPtr);
    }
}

template<class T, class V>
ostream& map<T, V>::InOrderDisplay(RBTreeNode<T, V> *nodePtr, ostream &strm)
{
    if(nodePtr != RBTree<T, V>::NIL){
        InOrderDisplay(nodePtr->left, strm);
        strm<<"("<<nodePtr->key<<", "<<nodePtr->value<<")";
        InOrderDisplay(nodePtr->right, strm);
    }
    return strm;
}

template<class T, class V>
void map<T, V>::InOrderVector(RBTreeNode<T, V> *nodePtr, vector<pair<T, V>>& vect)
{
    if(nodePtr != RBTree<T, V>::NIL){
        InOrderVector(nodePtr->left, vect);
        vect.push_back(make_pair(nodePtr->key, nodePtr->value));
        InOrderVector(nodePtr->right, vect);
    }
}

template<class T, class V>
bool map<T, V>::InOrderSubset(RBTreeNode<T, V> *nodePtr, map<T, V> &other)
{
    if(nodePtr != RBTree<T, V>::NIL){
        bool left = InOrderSubset(nodePtr->left, other);
        bool right = InOrderSubset(nodePtr->right, other);
        return (other.RBTree<T, V>::find(nodePtr->value) && left && right);
    }
    return true;
}

template<class T, class V>
bool map<T, V>::InOrderSubset(RBTreeNode<T, V> *nodePtr, RBTreeNode<T, V> *nilPtr)
{
    if(nodePtr != nilPtr){
        bool left = InOrderSubset(nodePtr->left, nilPtr);
        bool right = InOrderSubset(nodePtr->right, nilPtr);
        return (RBTree<T, V>::find(nodePtr->value) && left && right);
    }
    return true;
}

/*
 * overload the assignment operator
 */
template<class T, class V>
map<T, V> map<T, V>::operator=(const map<T, V>& right)
{
    RBTree<T, V>::destroySubTree(RBTree<T, V>::root);
    copy(right.RBTree<T, V>::root, RBTree<T, V>::root, RBTree<T, V>::NIL, right.RBTree<T, V>::NIL);
}

template<class T, class V>
int map<T, V>::size()
{
    vector<pair<T, V>> Vect;
    toVector(Vect);
    
    int size = Vect.size();
    
    return size;
}

template<class T, class V>
void map<T, V>::clear()
{
    vector<pair<T, V>> Vect;
    toVector(Vect);
    
    for(unsigned int i = 0; i<Vect.size(); i++)
        erase(Vect[i].first);
}

template<class T, class V>
V map<T, V>::get(T key)
{
    return RBTree<T, V>::findNode(key)->value;
}

template<class T, class V>
void map<T, V>::set(T key, V value)
{
    insert(key, value);
}

// convert the multiset to a vector
template<class T, class V>
void map<T, V>::toVector(vector<pair<T, V>>& vect)
{
    InOrderVector(RBTree<T, V>::root, vect);
}

template<class T, class V>
map<T, V>::map(const map<T, V> &right)
{
    copy(right.RBTree<T, V>::root, RBTree<T, V>::root, RBTree<T, V>::NIL, right.RBTree<T, V>::NIL);
}

template<class T, class V>
map<T, V>::~map()
{
    clear();
}

/*
 * Description: Insert function which calls the addElement function and only adds a non copy function
 * Parameters: item to be added
 */
template<class T, class V>
void map<T, V>::insert(T key, V value)
{
    RBTreeNode<T, V> *newnode = new RBTreeNode<T, V>(key, value, RED, RBTree<T, V>::NIL, RBTree<T, V>::NIL, RBTree<T, V>::NIL);
	RBTreeNode<T, V> *y = RBTree<T, V>::NIL;
	RBTreeNode<T, V> *x = RBTree<T, V>::root;

	while (x != RBTree<T, V>::NIL) {
		y = x;
		if (key < x->key)
			x = x->left;
		else
			x = x->right;
	}

	if(newnode->key == y->key){
        y->value = newnode->value;
        delete newNode;
        return;
    }

	newnode->parent = y;
	if (y == RBTree<T, V>::NIL)
		RBTree<T, V>::root = newnode;
	else if (newnode->key < y->key)
		y->left = newnode;
	else if(newnode->key > y->key)
		y->right = newnode;

	//  Adjust the RB tree to retain the properties.
    // if the value is not in the tree insert it
    RBTree<T, V>::insertFix(newnode);
}


/*
 * Find a value in the map
 */
template<class T, class V>
bool map<T, V>::find(T key)
{
    return RBTree<T, V>::find(key);
}


/*
 * Erase a value from the tree
 */
template<class T, class V>
void map<T, V>::erase(T key)
{
    RBTreeNode<T, V> *z = RBTree<T, V>::findNode(key);
	if (z == RBTree<T, V>::NIL)
		return;

	RBTreeNode<T, V> *y = z;
	RBTreeNode<T, V> *x = RBTree<T, V>::NIL;
	color_t yorigcol = y->color;

	if (z->left == RBTree<T, V>::NIL) {
		x = z->right;
		RBTree<T, V>::transplant(z, z->right);
	} else if (z->right == RBTree<T, V>::NIL) {
		x = z->left;
		RBTree<T, V>::transplant(z, z->left);
	} else {
		y = RBTree<T, V>::getMinNode(z->right);
		yorigcol = y->color;
		x = y->right;
		if (y->parent == z)
			x->parent = y;
		else {
			RBTree<T, V>::transplant(y, y->right);
			y->right = z->right;
			y->right->parent = y;
		}
		RBTree<T, V>::transplant(z, y);
		y->left = z->left;
		y->left->parent = y;
		y->color = z->color;
	}
	delete z;
	if (yorigcol == BLACK)
		RBTree<T, V>::deleteFix(x);
}

// empty function to check if empty
template<class T, class V>
bool map<T, V>::empty()
{
    bool checker = false;

    if(RBTree<T, V>::root == RBTree<T, V>::NIL)
        checker = true;

    return checker;
}

template<class T, class V>
bool map<T, V>::operator==(map<T, V>& right)
{
    return InOrderSubset(RBTree<T, V>::root, right) && InOrderSubset(right.RBTree<T, V>::root, right.RBTree<T, V>::NIL);
}

template<class T, class V>
bool map<T, V>::operator!=(map<T, V>& right)
{
    return !(InOrderSubset(RBTree<T, V>::root, right) && InOrderSubset(right.RBTree<T, V>::root, right.RBTree<T, V>::NIL));
}

template<class T, class V>
ostream& operator<<(ostream& os, map<T, V>& obj)
{

    os<<"{ ";
    vector<pair<T, V>> vect;
    obj.toVector(vect);
    for(unsigned int i = 0; i<vect.size(); i++){
        os<<"("<<vect[i].first<<","<<vect[i].second<<")";
        if(i != (vect.size() - 1))
            os<<", ";
    }
    os<<" }\n";
    return os;
}

#endif
